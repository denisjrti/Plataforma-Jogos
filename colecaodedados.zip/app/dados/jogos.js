export const jogosExclusivos = [
  {id: 1, nome: 'Contraband', plataforma: 'xbox'},
  {id: 2, nome: 'Avowed', plataforma: 'xbox'},
  {id: 3, nome: 'Starfield', plataforma: 'xbox'},
  {id: 4, nome: 'Fable', plataforma: 'xbox'},
  {id: 5, nome: 'Ghost of Tsushima', plataforma: 'playstation'},
  {id: 6, nome: 'Marvel´s Spider Man 2', plataforma: 'playstation'},
  {id: 7, nome: 'Death Stranding 2', plataforma: 'playstation'},
  {id: 8, nome: 'Final Fantasy XVI', plataforma: 'playstation'},
  {id: 9, nome: "Mario Odissey", plataforma: "nintendo" },
  {id: 10, nome: "Zelda: Tears of Kingdom", plataforma: "nintendo" },
  {id: 11, nome: "Xenoblade Chronicles 3", plataforma: "nintendo" },
  {id: 12, nome: "Pokemon Scarlet & Violet", plataforma: "nintendo" },
]